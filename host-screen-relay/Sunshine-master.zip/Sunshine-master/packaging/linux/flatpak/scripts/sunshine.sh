#!/bin/sh
exec sunshine "$@"
