# windows specific macros
